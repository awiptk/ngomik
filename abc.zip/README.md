NgomikReader - contoh aplikasi Android (Kotlin) untuk membaca komik dari id.ngomik.cloud

- Daftar manga menampilkan: cover, judul, dan tipe.
- Detail menampilkan: cover, judul, author, genre, tipe, deskripsi dan daftar chapter.
